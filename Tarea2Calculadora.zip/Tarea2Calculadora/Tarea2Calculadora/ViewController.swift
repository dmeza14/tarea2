//
//  ViewController.swift
//  Tarea2Calculadora
//
//  Created by David Meza on 27/8/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var labelOnScreen: UILabel!
    
    private var number1 = 0
    private var number2 = 0
    private var operation = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func acPressed(_ sender: Any) {
       
        labelOnScreen.text = "0"
        
        }
    
    @IBAction func numeros(_ sender: UIButton){
        labelOnScreen.text = String(sender.tag - 1)
        //number1 = sender.tag - 1
        
    }
    
    @IBAction func operaciones(_ sender: UIButton){
        
        number1 = Int(labelOnScreen.text!)!
        
        if sender.tag == 13 { //Dividir

        labelOnScreen.text = "/";

        }

        if sender.tag == 14 { //Multiplicar

        labelOnScreen.text = "x";

        }

        if sender.tag == 15 { //Restar

        labelOnScreen.text = "-";

        }

        if sender.tag == 16 { //Sumar

        labelOnScreen.text = "+";

        }

        operation = sender.tag
        labelOnScreen.text = ""
        number2 = Int(labelOnScreen.text!)!
        labelOnScreen.text = String(number1 + number2)
        
        
    }


}

